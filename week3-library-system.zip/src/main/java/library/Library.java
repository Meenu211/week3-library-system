package library;

import java.io.IOException;
import java.util.*;

public class Library {

    private List<Book> books;
    private List<Member> members;

    public Library() throws IOException {
        books = FileHandler.loadBooks();
        members = FileHandler.loadMembers();
    }

    public void addBook(Book book) throws IOException {
        books.add(book);
        FileHandler.saveBooks(books);
    }

    public void viewBooks() {
        for (Book book : books) {
            System.out.println(book.getId() + " | " + book.getTitle() + " | " +
                    book.getAuthor() + " | Borrowed: " + book.isBorrowed());
        }
    }

    public void registerMember(Member member) throws IOException {
        members.add(member);
        FileHandler.saveMembers(members);
    }

    public void borrowBook(String id) throws IOException {
        for (Book book : books) {
            if (book.getId().equals(id) && !book.isBorrowed()) {
                book.setBorrowed(true);
                FileHandler.saveBooks(books);
                System.out.println("Book borrowed successfully!");
                return;
            }
        }
        System.out.println("Book not available.");
    }

    public void returnBook(String id) throws IOException {
        for (Book book : books) {
            if (book.getId().equals(id) && book.isBorrowed()) {
                book.setBorrowed(false);
                FileHandler.saveBooks(books);
                System.out.println("Book returned successfully!");
                return;
            }
        }
        System.out.println("Invalid book ID.");
    }
}
