package library;

import java.io.*;
import java.util.*;

public class FileHandler {

    public static void saveBooks(List<Book> books) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter("data/books.txt"));
        for (Book book : books) {
            writer.write(book.toString());
            writer.newLine();
        }
        writer.close();
    }

    public static List<Book> loadBooks() throws IOException {
        List<Book> books = new ArrayList<>();
        File file = new File("data/books.txt");
        if (!file.exists()) return books;

        BufferedReader reader = new BufferedReader(new FileReader(file));
        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(",");
            books.add(new Book(parts[0], parts[1], parts[2], Boolean.parseBoolean(parts[3])));
        }
        reader.close();
        return books;
    }

    public static void saveMembers(List<Member> members) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter("data/members.txt"));
        for (Member member : members) {
            writer.write(member.toString());
            writer.newLine();
        }
        writer.close();
    }

    public static List<Member> loadMembers() throws IOException {
        List<Member> members = new ArrayList<>();
        File file = new File("data/members.txt");
        if (!file.exists()) return members;

        BufferedReader reader = new BufferedReader(new FileReader(file));
        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(",");
            members.add(new Member(parts[0], parts[1]));
        }
        reader.close();
        return members;
    }
}
