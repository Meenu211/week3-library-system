# Console-Based Library Management System

## Setup Instructions

Compile:
javac -d bin src/main/java/library/*.java

Run:
java -cp bin library.Main

## Features
- Add, view, borrow, return books
- Register members
- File-based data persistence
